package application.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import application.Main;
import application.MainController;

public class RollNumber_Decimal_Test {

	
@Test
public void testOne() {

    Main.launch();
    MainController theMainControllerObject = new MainController();
    MainController.EBMSHubs ebmsHubs=theMainControllerObject.getCurrentlyCalledHub();
    assertTrue(rollN.getText()-decimal.getText)().equals(result)));
}
}
